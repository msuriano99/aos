//Add your code here

//
// Created by masur on 1/28/2025.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

#define MAX_PATHS 50
#define MAX_ARGS 50
#define MAX_COMMANDS 50
#define BUFFER_SIZE 1024
#define ERROR_MESSAGE "An error has occurred\n"

// Function Prototypes
char *trimWhitespace(char *str);
void handleError();
void handleCdCommand(char *args[]);
int constructAndCheckPath(char *out_ptr, char *path[], char *full_path);
void handleExitCommand(char *args[]);
void handlePathCommand(char *args[], char *path[]);
void handleExternalCommand(int command_exists_flag, char *full_path, char *args[]);
void handleCommand(char *args[], char *path[], int command_exists_flag, char *full_path);
void handleRedirectionCommand(int command_exists_flag, char *full_path, char *args[], char *output);
void handleRedirection(char *redirection, char *path[], char *full_path);
void splitCommand(char *command, char *path[]);

// Function to trim leading and trailing whitespace
char *trimWhitespace(char *str) {
    if (str == NULL) return NULL;

    // Trim leading spaces
    while (isspace((unsigned char)*str)) {
        str++;
    }

    // If string is all spaces, return the empty string
    if (*str == '\0') {
        return str;
    }

    // Trim trailing spaces
    char *end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) {
        *end = '\0';
        end--;
    }

    return str;
}

// Function to handle errors
void handleError() {
    write(STDERR_FILENO, ERROR_MESSAGE, strlen(ERROR_MESSAGE));
}

// Function to handle 'cd' command
void handleCdCommand(char *args[]) {
    if (args[1] == NULL || args[2] != NULL) {
        handleError();
    } else {
        int result = chdir(args[1]);
        if (result == -1) {
            handleError();
        }
    }
}

// Function to construct the full path and check if the file exists
int constructAndCheckPath(char *out_ptr, char *path[], char *full_path) {
    for (int idx = 0; path[idx] != NULL; ++idx) {
        snprintf(full_path, PATH_MAX, "%s/%s", path[idx], out_ptr);

        if (access(full_path, X_OK) == 0) {
            return 1;  // File found and executable
        }
    }
    return 0;  // File not found in any path
}

// Function to handle 'exit' command
void handleExitCommand(char *args[]) {
    if (args[1] != NULL) {
        // There are additional arguments after 'exit'
        handleError();
    } else {
        // No additional arguments; proceed to exit
        exit(0);
    }
}


// Function to handle 'path' command
void handlePathCommand(char *args[], char *path[]) {
    // Clear existing path list
    for (int i = 0; i < MAX_PATHS; i++) {
        free(path[i]);  // Free previously allocated paths
        path[i] = NULL;
    }

    // Copy new paths from args[1] onwards
    for (int i = 0; i < MAX_PATHS - 1 && args[i + 1] != NULL; i++) {
        path[i] = strdup(args[i + 1]);  // Copy string safely
    }
}

// Function to handle external commands
void handleExternalCommand(int command_exists_flag, char *full_path, char *args[]) {
    if (command_exists_flag == 1) {
        pid_t pid = fork();
        if (pid == 0) {
            // Child process: Execute the command
            execv(full_path, args);
            // If execv fails, exit the child process
            handleError();
            exit(1);
        } else if (pid == -1) {
            // Fork failed
            handleError();
        }
    } else {
        // Command not found: Print an error
        handleError();
    }
}

// Function to route commands to appropriate handlers
void handleCommand(char *args[], char *path[], int command_exists_flag, char *full_path) {
    if (strcmp(args[0], "cd") == 0) {
        handleCdCommand(args);
    } else if (strcmp(args[0], "exit") == 0) {
        handleExitCommand(args);
    } else if (strcmp(args[0], "path") == 0) {
        handlePathCommand(args, path);
    } else if (path[0] != NULL) {
        handleExternalCommand(command_exists_flag, full_path, args);
    } else {
        handleError();
    }
}

// Function to handle redirection commands
void handleRedirectionCommand(int command_exists_flag, char *full_path, char *args[], char *output) {
    if (command_exists_flag == 1) {
        pid_t pid = fork();
        if (pid == 0) {
            // Open the file and redirect stdout to it
            freopen(output, "w", stdout);
            // Execute the command
            execv(full_path, args);
            // If execv fails, handle error and exit
            handleError();
            exit(1);
        } else if (pid == -1) {
            // Fork failed
            handleError();
        }
    } else {
        // Command not found: Print an error
        handleError();
    }
}

// Function to parse and handle redirection
void handleRedirection(char *redirection, char *path[], char *full_path) {
    char *out_ptr;
    char *in_ptr = redirection;
    const char *del = ">";
    const char *del1 = " ";

    char *command = NULL;
    char *output_file = NULL;

    int i = 0;
    while ((out_ptr = strsep(&in_ptr, del)) != NULL) {
        out_ptr = trimWhitespace(out_ptr);

        // Skip empty commands
        if (strlen(out_ptr) == 0) {
            continue;
        }
        if (i == 0) {
            command = out_ptr;
        } else if (i == 1) {
            output_file = out_ptr;
        } else {
            // Multiple '>' operators: error
            handleError();
            return;
        }
        i++;
    }

    if (i != 2) {
        // Missing output file or too many '>' operators
        handleError();
        return;
    }

    // **New Code Begins Here**
    // Ensure that output_file contains exactly one filename
    char *check_ptr = output_file;
    char *token = strsep(&check_ptr, del1);

    if (token == NULL) {
        // No output file specified
        handleError();
        return;
    }

    // Check if there are additional tokens (i.e., multiple filenames)
    token = strsep(&check_ptr, del1);
    if (token != NULL) {
        // Multiple files after '>' operator: error
        handleError();
        return;
    }
    // **New Code Ends Here**

    // Now, split command into arguments
    char *args[MAX_ARGS] = {NULL};
    int idx = 0;
    in_ptr = command;
    while ((out_ptr = strsep(&in_ptr, del1)) != NULL) {
        out_ptr = trimWhitespace(out_ptr);
        if (out_ptr != NULL && strlen(out_ptr) > 0) {
            args[idx] = out_ptr;
            idx++;
            if (idx >= MAX_ARGS - 1) break;
        }
    }
    args[idx] = NULL;  // Null-terminate the args array

    // Check Path
    int command_exists_flag = constructAndCheckPath(args[0], path, full_path);

    // Handle Command with Redirection
    handleRedirectionCommand(command_exists_flag, full_path, args, output_file);
}


// Function to split and execute commands
void splitCommand(char *command, char *path[]) {
    char full_path[PATH_MAX];
    int command_exists_flag = 0;

    int i = 0;
    char *in_ptr = command;
    char *out_ptr;
    int pid_count = 0;
    const char *del1 = "&";
    const char *del = " ";

    char *commands[MAX_COMMANDS] = {NULL};

    // Split commands by '&'
    while ((out_ptr = strsep(&in_ptr, del1)) != NULL) {
        out_ptr = trimWhitespace(out_ptr);

        // Skip empty commands
        if (strlen(out_ptr) == 0) {
            continue;
        }
        commands[i] = out_ptr;
        i++;
        if (i >= MAX_COMMANDS - 1) break;
    }

    for (i = 0; commands[i] != NULL; i++) {
        in_ptr = commands[i];
        int redirection_flag = 0;
        int error_flag = 0;

        // Check for '>' for redirection
        for (int idx = 0; in_ptr[idx] != '\0'; idx++) {
            if (in_ptr[idx] == '>') {
                if (redirection_flag == 1) {
                    // Multiple redirections: error
                    handleError();
                    error_flag = 1;
                    break;
                }
                redirection_flag = 1;
            }
        }
        if (error_flag == 1) {
            continue;
        }
        else if (redirection_flag == 1) {
            handleRedirection(commands[i], path, full_path);
            pid_count++;
        } else {
            char *args[MAX_ARGS] = {NULL};

            int idx_arg = 0;
            while ((out_ptr = strsep(&in_ptr, del)) != NULL) {
                out_ptr = trimWhitespace(out_ptr);
                if (out_ptr != NULL && strlen(out_ptr) > 0) {
                    args[idx_arg] = out_ptr;
                    idx_arg++;
                    if (idx_arg >= MAX_ARGS - 1) break;
                }
            }
            args[idx_arg] = NULL;  // Null-terminate the args array

            // Check Path
            command_exists_flag = constructAndCheckPath(args[0], path, full_path);

            // Handle Command
            handleCommand(args, path, command_exists_flag, full_path);
            pid_count++;
        }
    }

    // Wait for all child processes to finish
    for (int j = 0; j < pid_count; j++) {
        wait(NULL);
    }
}

int main(int argc, char *argv[]) {
    char *command = NULL;
    size_t command_size = 0;
    FILE *input_stream = stdin;
    int interactive_mode = 1;

    // Initialize path with /bin
    char *path[MAX_PATHS] = {NULL};
    path[0] = strdup("/bin");

    // Handle command-line arguments for batch mode
    if (argc > 2) {
        handleError();
        exit(1);
    } else if (argc == 2) {
        // Batch mode
        input_stream = fopen(argv[1], "r");
        if (input_stream == NULL) {
            handleError();
            exit(1);
        }
        interactive_mode = 0;
    }

    while (1) {
        if (interactive_mode) {
            printf("wish> ");
        }

        ssize_t len = getline(&command, &command_size, input_stream);

        if (len == -1) {
            // End of file or error
            break;
        }

        // Remove trailing newline if present
        if (len > 0 && command[len - 1] == '\n') {
            command[len - 1] = '\0';
        }

        // Trim whitespace
        char *trimmed_command = trimWhitespace(command);

        // Skip empty commands
        if (trimmed_command == NULL || strlen(trimmed_command) == 0) {
            continue;
        }

        // Split and execute the command
        splitCommand(trimmed_command, path);
    }

    // Clean up
    free(command);
    for (int i = 0; i < MAX_PATHS && path[i] != NULL; i++) {
        free(path[i]);
    }

    if (input_stream != stdin) {
        fclose(input_stream);
    }

    return 0;
}
